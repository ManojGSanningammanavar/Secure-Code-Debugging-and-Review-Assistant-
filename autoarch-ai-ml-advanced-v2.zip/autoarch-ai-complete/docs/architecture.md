# AutoArch AI — Architecture and engineering notes

## Runtime architecture

- **React + Vite UI**: upload workflow, inventory, candidate graph, evidence assistant, revision comparison and engineering review.
- **FastAPI API**: validates uploads, extracts text, builds candidate entities, retrieves evidence, compares revisions and emits exports.
- **Extraction layer**: PyMuPDF for selectable-text PDFs, python-docx for DOCX, UTF-8 decoding for TXT/Markdown. Page/section values are provenance hints, not guaranteed original pagination for DOCX/TXT.
- **Retrieval layer**: TF-IDF cosine ranking when scikit-learn is installed, keyword fallback otherwise. Optional OpenAI-compatible completion endpoint receives retrieved evidence and is prompted to avoid unsupported claims.
- **Local persistence**: SQLite stores parsed document payloads; uploaded originals are written under `backend/data/uploads/`.

## Data flow

1. User uploads a document. The API checks extension and byte size, extracts selectable text and rejects empty extraction.
2. Text is normalized and scanned for candidate component/interface names and relationship phrases.
3. Evidence snippets retain a page/section index. Candidate relationships carry a basis such as `explicit_phrase` or `co_occurrence`.
4. Q&A ranks snippets and returns evidence. If a compatible model is configured, it can synthesize a grounded response; otherwise the API stays in retrieval-only mode.
5. Revision compare computes added/removed passages and entities, explores candidate dependency edges, and emits a review checklist.
6. Engineering review checks for evidence of selected topics and explicitly distinguishes “mentioned” from validated implementation.

## Trust and safety boundaries

- Extracted component names and links are candidates; text co-occurrence is not proof of a dependency.
- Review findings are not safety/cybersecurity compliance assessments and do not establish AUTOSAR conformance.
- Source documents are treated as untrusted context by the optional model prompt.
- Do not upload proprietary or confidential documents unless the execution environment is approved by the document owner.
- Production deployment would need authentication, authorization, audit logging, retention controls, encrypted transport, robust tenant isolation, durable migrations, malware scanning, OCR governance, rate limiting, and qualified validation.

## Roadmap for a production-grade system

1. Replace heuristic entity extraction with configurable schema-aware parsing and architecture-model imports.
2. Add OCR with explicit confidence and human correction workflows.
3. Add hybrid lexical/vector retrieval with reranking and evaluated citation precision.
4. Use versioned normalized tables, user/project access control, audit history and managed object storage.
5. Add golden-set evaluations for extraction precision/recall, answer faithfulness, impact analysis and false-positive rates.
6. Add approved AUTOSAR/OEM rule packs and traceability links only when authoritative source material and licensing permit.
7. Require human approval for engineering findings; never automate design approval or safety certification.


## Retrieval model options

Default: TF-IDF ranking. Optional: sentence-transformer embeddings (`all-MiniLM-L6-v2`) for semantic retrieval, with an optional cross-encoder (`ms-marco-MiniLM-L-6-v2`) to rerank candidate passages. These are opt-in because they add installation size, model downloads, CPU/memory use, and startup latency.
