from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def upload(name, content):
    return client.post("/api/documents", files={"file": (name, content.encode("utf-8"), "text/plain")})

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_upload_inventory_and_evidence():
    sample = """Architecture Overview
The BodyController communicates with the CanGateway through the VehicleStatusInterface.
The CanGateway routes vehicle signals to the DiagnosticManager.
The DiagnosticManager reports faults to the EventMonitor.
"""
    response = upload("sample_hld.txt", sample)
    assert response.status_code == 200
    body = response.json()
    assert body["document"]["pages"] == 1
    assert body["document"]["components"] >= 2
    assert "interfaces" in body
    doc_id = body["document"]["id"]
    ask = client.post(f"/api/documents/{doc_id}/ask", json={"question": "Which components communicate with the gateway?"})
    assert ask.status_code == 200
    assert "evidence" in ask.json()
    assert ask.json()["mode"] in {"retrieval_only", "grounded_llm", "no_match"}

def test_revision_comparison_has_impact_and_checks():
    first = """Architecture
The BodyController communicates with the CanGateway through the VehicleStatusInterface.
The CanGateway routes signals to the DiagnosticManager.
The DiagnosticManager reports faults to the EventMonitor.
"""
    second = """Architecture revision 2
The BodyController communicates with the CanGateway through the VehicleStatusInterface.
The CanGateway routes signals to the DiagnosticManager.
The DiagnosticManager reports faults to the EventMonitor.
The BatteryMonitor sends events to the DiagnosticManager through BatteryStatusInterface.
"""
    a = upload("hld_v1.txt", first).json()["document"]["id"]
    b = upload("hld_v2.txt", second).json()["document"]["id"]
    result = client.post("/api/compare", json={"base_document_id": a, "new_document_id": b})
    assert result.status_code == 200
    body = result.json()
    assert "impact" in body
    assert "suggested_tests" in body
    assert body["summary"]["added_passages"] >= 1

def test_rejects_unsupported_file():
    response = client.post("/api/documents", files={"file": ("file.exe", b"abc", "application/octet-stream")})
    assert response.status_code == 415

def test_engineering_review_reports_evidence_and_limits():
    content = """Architecture Review\nThe DiagnosticManager reports faults through DiagnosticInterface.\nThe CanGateway routes CAN signals and uses watchdog supervision.\n"""
    doc_id = upload("review_hld.txt", content).json()["document"]["id"]
    response = client.get(f"/api/documents/{doc_id}/review")
    assert response.status_code == 200
    body = response.json()
    assert body["summary"]["total"] >= 5
    assert any(f["title"] == "Diagnostic behavior" and f["evidence"] for f in body["findings"])
    assert "not a" in body["disclaimer"].lower()

def test_search_endpoint_and_document_delete():
    doc_id = upload("search_delete.txt", "The BatteryMonitor sends battery health events to the DiagnosticManager through BatteryStatusInterface.").json()["document"]["id"]
    search = client.post(f"/api/documents/{doc_id}/search", json={"question": "BatteryMonitor battery health"})
    assert search.status_code == 200
    assert search.json()["count"] >= 1
    deleted = client.delete(f"/api/documents/{doc_id}")
    assert deleted.status_code == 200
    assert client.get(f"/api/documents/{doc_id}").status_code == 404

def test_docx_upload_extracts_paragraphs():
    from io import BytesIO
    from docx import Document
    file_obj = BytesIO()
    document = Document()
    document.add_heading("Architecture Overview", level=1)
    document.add_paragraph("The BodyController communicates with the CanGateway through VehicleStatusInterface.")
    document.save(file_obj)
    response = client.post("/api/documents", files={"file": ("architecture.docx", file_obj.getvalue(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert response.status_code == 200
    body = response.json()
    assert body["document"]["pages"] >= 1
    assert any("BodyController" in page["text"] for page in client.get(f"/api/documents/{body['document']['id']}/pages").json()["pages"])


def test_ml_insights_endpoint_returns_evidence_and_disclaimer():
    content = """Architecture
The DiagnosticManager detects diagnostic faults and reports DTC events.
The CanGateway routes CAN signals and applies communication timeout handling.
Requirements include a verification test for diagnostic recovery.
"""
    doc_id = upload("ml_insights.txt", content).json()["document"]["id"]
    response = client.get(f"/api/documents/{doc_id}/ml-insights")
    assert response.status_code == 200
    body = response.json()
    assert len(body["insights"]) >= 5
    assert any(item["topic"] == "Diagnostics" and item["evidence"] for item in body["insights"])
    assert "not probabilities" in body["disclaimer"]
