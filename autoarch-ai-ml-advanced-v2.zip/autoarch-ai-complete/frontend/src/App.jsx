import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Activity, AlertTriangle, ArrowUpRight, Bot, Check, ChevronDown, CircleHelp, Download, FileText, GitCompare, Layers3, Network, Plus, Search, ShieldCheck, Sparkles, UploadCloud, X, Zap } from 'lucide-react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const sampleText = `AUTOSAR HIGH-LEVEL DESIGN — DEMONSTRATION DOCUMENT
Version: 1.0
Project: Demo Vehicle Body Domain

1. System Overview
The BodyController coordinates window, door-lock, and cabin-light functions. The BodyController communicates with the CanGateway through the VehicleStatusInterface.
The CanGateway routes selected vehicle signals to the DiagnosticManager. The DiagnosticManager receives diagnostic requests through the DiagnosticInterface and reports detected faults to the EventMonitor.
The EventMonitor records fault status and sends events to the HealthMonitoringService. The HealthMonitoringService monitors service availability and notifies the BodyController when degraded mode is required.

2. Interfaces and Data Flow
The VehicleStatusInterface carries door state, window state, and cabin-light status. The DiagnosticInterface connects the CanGateway and DiagnosticManager.
The HealthMonitoringService sends a degraded-mode notification to BodyController. These relationships are candidates extracted from design narrative and require architecture-owner confirmation.

3. Constraints
The CanGateway must route only approved signals. The DiagnosticManager must not change body-control outputs directly. EventMonitor records diagnostic state but does not approve safety decisions.
All dependencies and interface definitions must be verified against the project's authoritative architecture model before implementation.

4. Verification Notes
Test engineers should verify VehicleStatusInterface producer-consumer behavior, diagnostic event delivery, and degraded-mode notification. This synthetic example is not an official AUTOSAR, OEM, or vehicle specification.`

const sampleV2 = sampleText.replace('Version: 1.0', 'Version: 2.0').replace(
  'The EventMonitor records fault status and sends events to the HealthMonitoringService.',
  'The EventMonitor records fault status and sends events to the HealthMonitoringService. The BatteryMonitor sends battery health events to the DiagnosticManager through BatteryStatusInterface.'
).replace('This synthetic example', 'The BatteryMonitor addition needs integration and diagnostic regression tests. This synthetic example')

export default function App() {
  const [documents, setDocuments] = useState([])
  const [activeId, setActiveId] = useState('')
  const [activeData, setActiveData] = useState(null)
  const [query, setQuery] = useState('')
  const [answer, setAnswer] = useState(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [tab, setTab] = useState('overview')
  const [compareBase, setCompareBase] = useState('')
  const [compareResult, setCompareResult] = useState(null)
  const [reviewResult, setReviewResult] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [toast, setToast] = useState('')
  const inputRef = useRef(null)
  const activeDoc = documents.find(d => d.id === activeId)
  const components = activeData?.components || []
  const dependencies = activeData?.dependencies || []
  const interfaces = activeData?.interfaces || []
  const filteredComponents = useMemo(() => components.filter(c => `${c.name} ${c.type}`.toLowerCase().includes(searchTerm.toLowerCase())), [components, searchTerm])

  async function request(path, options = {}) {
    const res = await fetch(`${API}${path}`, options)
    const body = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(body.detail || `Request failed (${res.status})`)
    return body
  }
  async function refreshDocs(selectId) {
    const docs = await request('/api/documents')
    setDocuments(docs)
    if (selectId) setActiveId(selectId)
    else if (!activeId && docs[0]) setActiveId(docs[0].id)
  }
  async function loadDoc(id) {
    if (!id) { setActiveData(null); return }
    try { const data = await request(`/api/documents/${id}`); setActiveData(data); setActiveId(id); setAnswer(null); setCompareResult(null); setReviewResult(null) }
    catch (e) { setError(e.message) }
  }
  useEffect(() => { refreshDocs().catch(() => setError('Backend is not connected. Start FastAPI on port 8000.')) }, [])
  useEffect(() => { if (activeId) loadDoc(activeId) }, [activeId])

  async function upload(file) {
    if (!file) return
    setBusy(true); setError('')
    try {
      const form = new FormData(); form.append('file', file)
      const result = await request('/api/documents', { method: 'POST', body: form })
      await refreshDocs(result.document.id); setActiveId(result.document.id); setActiveData(result); setTab('overview')
      setToast(`Imported ${file.name}`); setTimeout(() => setToast(''), 2600)
    } catch (e) { setError(e.message) } finally { setBusy(false) }
  }
  async function loadSample(version = 1) {
    const text = version === 1 ? sampleText : sampleV2
    const name = version === 1 ? 'sample_hld_v1.txt' : 'sample_hld_v2.txt'
    await upload(new File([new Blob([text], {type:'text/plain'})], name, {type:'text/plain'}))
  }
  async function ask(e) {
    e?.preventDefault()
    if (!activeId || query.trim().length < 2) return
    setBusy(true); setError('')
    try { setAnswer(await request(`/api/documents/${activeId}/ask`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({question:query})})) }
    catch (e) { setError(e.message) } finally { setBusy(false) }
  }
  async function runReview() {
    if (!activeId) return
    setBusy(true); setError('')
    try { setReviewResult(await request(`/api/documents/${activeId}/review`)) }
    catch (e) { setError(e.message) } finally { setBusy(false) }
  }
  async function compare() {
    if (!compareBase || !activeId || compareBase === activeId) return
    setBusy(true); setError('')
    try { setCompareResult(await request('/api/compare', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({base_document_id:compareBase,new_document_id:activeId})})) }
    catch (e) { setError(e.message) } finally { setBusy(false) }
  }
  function download(path, filename) {
    const a=document.createElement('a'); a.href=`${API}${path}`; a.download=filename
    document.body.appendChild(a); a.click(); a.remove()
  }
  const graphNodes = components.slice(0,7).map((n,i)=>({...n,x:18+(i%3)*31,y:20+Math.floor(i/3)*29}))
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Layers3 size={20}/></div><div><strong>autoarch<span>.ai</span></strong><small>ENGINEERING INTELLIGENCE</small></div></div>
      <div className="workspace-label">WORKSPACE <ChevronDown size={13}/></div>
      <Nav active={tab} setTab={setTab} icon={Activity} id="overview" label="Overview"/>
      <Nav active={tab} setTab={setTab} icon={Network} id="components" label="Architecture map"/>
      <Nav active={tab} setTab={setTab} icon={Bot} id="assistant" label="Ask your HLD" badge="AI"/>
      <Nav active={tab} setTab={setTab} icon={ShieldCheck} id="review" label="Engineering review"/>
      <Nav active={tab} setTab={setTab} icon={GitCompare} id="compare" label="Revision compare"/>
      <div className="sidebar-section"><span>PROJECT DOCUMENTS</span><button className="icon-button subtle" onClick={()=>inputRef.current?.click()} title="Add document"><Plus size={15}/></button></div>
      <div className="document-list">{documents.map(d=><button key={d.id} className={`doc-link ${activeId===d.id?'active':''}`} onClick={()=>setActiveId(d.id)}><FileText size={15}/><span>{d.filename}</span><small>{d.pages}p</small></button>)}{!documents.length&&<p className="empty-side">No documents yet. Import an HLD to begin.</p>}</div>
      <div className="sidebar-bottom"><div className="secure-icon"><ShieldCheck size={17}/></div><div><strong>Local-first workspace</strong><small>Files processed by your local API</small></div><span className="online-dot"/></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="breadcrumbs"><span>Workspace</span><span className="crumb-slash">/</span><strong>{({overview:'Overview',components:'Architecture map',assistant:'Ask your HLD',review:'Engineering review',compare:'Revision compare'})[tab]}</strong></div><div className="top-actions"><div className="system-status"><span className="online-dot"/> SYSTEM OPERATIONAL</div><button className="avatar">AA</button></div></header>
      <div className="content">
        <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> AUTOMOTIVE ENGINEERING AI <span className="pill">ASSESSMENT BUILD</span></div><h1>{({overview:'Architecture intelligence',components:'Architecture map',assistant:'Ask your HLD',review:'Engineering review',compare:'Revision comparison'})[tab]}</h1><p>{({overview:'Turn complex design documents into connected, searchable engineering knowledge.',components:'Explore detected components, interfaces and candidate relationships.',assistant:'Retrieve evidence and optionally synthesize grounded answers.',review:'Run evidence-linked heuristic checks across important engineering concerns.',compare:'Trace changes across revisions and plan verification reviews.'})[tab]}</p></div><div className="heading-actions"><button className="btn btn-secondary" onClick={()=>activeId&&download(`/api/documents/${activeId}/inventory.csv`,'architecture_inventory.csv')} disabled={!activeId}><Download size={15}/> Export inventory</button><button className="btn btn-primary" onClick={()=>inputRef.current?.click()}><UploadCloud size={16}/> Import HLD</button><input ref={inputRef} type="file" accept=".pdf,.txt,.md,.docx" hidden onChange={e=>{upload(e.target.files?.[0]);e.target.value=''}}/></div></div>
        {error&&<div className="alert error"><AlertTriangle size={17}/><span>{error}</span><button onClick={()=>setError('')}><X size={15}/></button></div>}
        {!activeDoc?<section className="welcome-panel"><div className="welcome-icon"><UploadCloud size={27}/></div><h2>Bring your architecture to life</h2><p>Import an automotive HLD to extract components, inspect dependencies, search evidence and compare revisions.</p><div className="welcome-actions"><button className="btn btn-primary" onClick={()=>inputRef.current?.click()}><UploadCloud size={16}/> Upload a document</button><button className="btn btn-secondary" onClick={()=>loadSample(1)} disabled={busy}><Sparkles size={16}/> Try interactive demo</button></div><small>PDF, TXT, MD, DOCX · Up to 20 MB · Scanned PDF OCR not included</small></section>:<>
          <section className="document-banner"><div className="file-icon"><FileText size={20}/></div><div className="file-meta"><strong>{activeDoc.filename}</strong><span><span className="status-dot"/> Indexed in current session <span className="meta-sep">·</span>{activeDoc.pages} pages<span className="meta-sep">·</span>{activeDoc.characters.toLocaleString()} characters</span></div><div className="banner-right"><span className="confidence-label"><ShieldCheck size={14}/> Evidence mode</span><button className="icon-button" onClick={()=>download(`/api/documents/${activeId}/export.json`,'autoarch_findings.json')} title="Export findings"><Download size={17}/></button></div></section>
          {tab==='overview'&&<><div className="metrics-grid"><Metric icon={<Layers3/>} label="Detected components" value={activeDoc.components} note="Heuristic extraction" trend="Inventory"/><Metric icon={<Network/>} label="Candidate dependencies" value={activeDoc.dependencies} note="Engineer review required" trend="Traceability"/><Metric icon={<FileText/>} label="Pages indexed" value={activeDoc.pages} note="Source text retained" trend="Source"/><Metric icon={<Zap/>} label="Interfaces detected" value={activeDoc.interfaces} note="Name-pattern extraction" trend="Contracts"/></div>
            <div className="section-title-row"><div><h2>Architecture at a glance</h2><p>Extracted entities and candidate links from the current document.</p></div><button className="text-button" onClick={()=>setTab('components')}>Explore architecture <ArrowUpRight size={15}/></button></div>
            <div className="overview-grid"><section className="panel graph-panel"><div className="panel-header"><div><h3>Component dependency map</h3><p>Inferred from design text; not authoritative</p></div><span className="mini-tag"><span className="status-dot"/> LIVE MAP</span></div><Graph nodes={graphNodes} edges={dependencies}/><div className="graph-legend"><span><i className="legend-node"/> Component</span><span><i className="legend-line"/> Candidate relationship</span><span className="legend-note">Validate before use</span></div></section>
              <section className="panel insight-panel"><div className="panel-header"><div><h3>Engineering review signals</h3><p>Review before design approval</p></div><div className="signal-icon"><Zap size={17}/></div></div><Signal number={components.length} tone="amber" title="Extracted entities" text="Verify against the approved component catalogue."/><Signal number={dependencies.length} tone="blue" title="Candidate relationships" text="Confirm direction, ports and interface contracts."/><Signal number={interfaces.length} tone="green" title="Interface-like names" text="Confirm types and producer-consumer semantics."/><button className="btn btn-secondary full-width" onClick={()=>setTab('components')}>Review extracted inventory <ArrowUpRight size={15}/></button></section></div>
            <section className="panel inventory-panel"><div className="panel-header"><div><h3>Component inventory</h3><p>Detected entities with source evidence</p></div><button className="text-button" onClick={()=>setTab('components')}>View all <ArrowUpRight size={14}/></button></div><Inventory rows={components.slice(0,5)}/></section></>}
          {tab==='components'&&<><section className="panel inventory-panel"><div className="panel-header"><div><h3>Extracted components</h3><p>Search entities and review source evidence.</p></div><div className="search-box"><Search size={15}/><input value={searchTerm} onChange={e=>setSearchTerm(e.target.value)} placeholder="Search inventory..."/></div></div><Inventory rows={filteredComponents}/><div className="panel-footer"><span>{filteredComponents.length} of {components.length} components</span><button className="btn btn-secondary" onClick={()=>download(`/api/documents/${activeId}/inventory.csv`,'architecture_inventory.csv')}><Download size={15}/> Download CSV</button></div></section><section className="panel inventory-panel"><div className="panel-header"><div><h3>Interface inventory</h3><p>Names that match interface, port, signal, API or service patterns.</p></div></div><Inventory rows={interfaces.map(x=>({...x,type:'Interface / Signal'}))}/></section><section className="panel inventory-panel"><div className="panel-header"><div><h3>Candidate dependency map</h3><p>Edges carry source evidence and extraction basis in the JSON export.</p></div></div><Graph nodes={graphNodes} edges={dependencies}/></section></>}
          {tab==='assistant'&&<div className="assistant-layout"><section className="panel chat-panel"><div className="chat-intro"><div className="assistant-orb"><Bot size={23}/></div><div><h2>Architecture evidence assistant</h2><p>Local retrieval with optional grounded LLM synthesis.</p></div></div><div className="suggested-queries"><span>TRY ASKING</span>{['Summarize the architecture','Which components communicate with the gateway?','What interfaces are mentioned?','What should engineers verify?'].map(q=><button key={q} onClick={()=>setQuery(q)}>{q}<ArrowUpRight size={13}/></button>)}</div><form className="question-form" onSubmit={ask}><div className="question-input"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Ask a question about this HLD..." minLength={2}/><button className="btn btn-primary" disabled={busy||query.trim().length<2}>{busy?'Searching…':'Find evidence'} <ArrowUpRight size={15}/></button></div><small><ShieldCheck size={12}/> Answers use uploaded source passages; model is optional.</small></form>
              {answer?<div className="answer-block"><div className="answer-heading"><Sparkles size={17}/><strong>Search result</strong><span className={answer.mode==='grounded_llm'?'result-chip':'result-chip muted'}>{answer.mode==='grounded_llm'?'GROUNDED AI':answer.mode==='retrieval_only'?'SOURCE RETRIEVAL':'NO MATCH'}</span></div><p>{answer.answer}</p><div className="answer-notice"><ShieldCheck size={13}/>{answer.notice}</div><h4>Source evidence <span>{answer.evidence.length} passages</span></h4>{answer.evidence.map((ev,i)=><div className="evidence-card" key={i}><div className="evidence-meta"><span><FileText size={13}/> Page {ev.page}</span><span>Score {ev.score}</span></div><p>{ev.text}</p></div>)}</div>:<div className="assistant-empty"><CircleHelp size={21}/><strong>Your evidence will appear here</strong><span>Choose a suggested question or ask your own.</span></div>}</section>
            <aside className="panel assistant-side"><h3>Search principles</h3><Principle title="Source-linked" text="Each evidence result retains a physical page reference."/><Principle title="Transparent retrieval" text="TF-IDF search is used when available, with keyword fallback."/><Principle title="Optional model synthesis" text="Configured LLM answers are instructed to cite retrieved pages."/><div className="note-box"><AlertTriangle size={16}/><p>Confirm every citation and conclusion. This is not a certified engineering tool.</p></div></aside></div>}
          {tab==='review'&&<section className="panel compare-panel"><div className="compare-intro"><div className="compare-icon"><ShieldCheck size={22}/></div><div><h2>Engineering review signals</h2><p>Evidence-aware presence checks for safety, cybersecurity, diagnostics, communications, persistence and liveness.</p></div><button className="btn btn-primary" onClick={runReview} disabled={busy||!activeId}><ShieldCheck size={15}/> Run review</button></div>{!reviewResult?<div className="compare-empty"><ShieldCheck size={25}/><strong>Review findings appear here</strong><span>Run the review against the active HLD. Findings are heuristics, not compliance verdicts.</span></div>:<><div className="compare-notice"><AlertTriangle size={15}/>{reviewResult.disclaimer}</div><div className="compare-metrics">{Object.entries(reviewResult.summary).map(([k,v])=><div className="compare-metric" key={k}><span>{k.replaceAll('_',' ')}</span><strong>{v}</strong></div>)}</div><div className="impact-panel"><div className="panel-header"><div><h3>Review findings</h3><p>“Mentioned” means text was found; it does not prove implementation or correctness.</p></div></div>{reviewResult.findings.map(f=><div className="test-row" key={f.id}><span className={`priority ${f.priority.toLowerCase()}`}>{f.priority}</span><div><strong>{f.title}</strong><p>{f.status} · {f.recommendation}</p>{f.evidence.map((e,i)=><small key={i}>Page {e.page}: {e.text}</small>)}</div></div>)}</div><div className="panel-footer"><span>Heuristic screening only · engineer validation required</span><button className="btn btn-secondary" onClick={()=>download(`data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(reviewResult,null,2))}`,'autoarch_review.json')}><Download size={15}/> Export review</button></div></>}</section>}
          {tab==='compare'&&<section className="panel compare-panel"><div className="compare-intro"><div className="compare-icon"><GitCompare size={22}/></div><div><h2>Compare HLD revisions</h2><p>Identify text, component and interface changes; inspect candidate downstream impact.</p></div></div><div className="quick-demo"><span>QUICK DEMO</span><button className="btn btn-secondary" onClick={()=>loadSample(1)} disabled={busy}><Plus size={14}/> Load demo v1</button><button className="btn btn-secondary" onClick={()=>loadSample(2)} disabled={busy}><Plus size={14}/> Load demo v2</button></div><div className="compare-controls"><label>Baseline revision<select value={compareBase} onChange={e=>setCompareBase(e.target.value)}><option value="">Select baseline…</option>{documents.filter(d=>d.id!==activeId).map(d=><option key={d.id} value={d.id}>{d.filename}</option>)}</select></label><div className="compare-arrow">→</div><label>New revision<div className="current-revision">{activeDoc.filename}<span>Current</span></div></label><button className="btn btn-primary" onClick={compare} disabled={!compareBase||busy}><GitCompare size={15}/> Compare revisions</button></div>
            {!compareResult?<div className="compare-empty"><GitCompare size={25}/><strong>Revision insights appear here</strong><span>Load two demo revisions or upload two documents, then select a baseline.</span></div>:<><div className="compare-notice"><AlertTriangle size={15}/>{compareResult.notice}</div><div className="compare-metrics">{Object.entries(compareResult.summary).map(([k,v])=><div className="compare-metric" key={k}><span>{k.replaceAll('_',' ')}</span><strong>{v}</strong></div>)}</div><div className="impact-panel"><div className="panel-header"><div><h3>Potential downstream impact</h3><p>Candidate paths inferred from the union of both revision graphs.</p></div></div>{compareResult.impact?.length?<div className="impact-list">{compareResult.impact.map((item,i)=><div className="impact-row" key={i}><span className="impact-depth">L{item.depth}</span><div><strong>{item.component}</strong><p>Potentially downstream of {item.upstream_changed_component} · source p.{item.page}</p><small>{item.evidence}</small></div><span className="type-pill">{item.basis}</span></div>)}</div>:<p className="no-diff">No downstream path could be inferred. Review changed entities manually.</p>}</div><div className="diff-grid"><DiffList title="Added components" rows={compareResult.added_components} type="added"/><DiffList title="Removed components" rows={compareResult.removed_components} type="removed"/><DiffList title="Added interfaces" rows={compareResult.added_interfaces} type="added"/><DiffList title="Removed interfaces" rows={compareResult.removed_interfaces} type="removed"/></div><div className="impact-panel"><div className="panel-header"><div><h3>Suggested verification checklist</h3><p>Candidate checks only; review against project test strategy.</p></div></div>{compareResult.suggested_tests.map((t,i)=><div className="test-row" key={i}><span className={`priority ${t.priority.toLowerCase()}`}>{t.priority}</span><div><strong>{t.check}</strong><p>{t.reason}</p><small>{t.status}</small></div></div>)}</div><div className="panel-footer"><span>Comparison report is generated from current-session documents.</span><button className="btn btn-secondary" onClick={()=>download(`data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(compareResult,null,2))}`,'autoarch_change_impact.json')}><Download size={15}/> Export impact report</button></div></>}
          </section>}
        </>}
        <footer className="footer"><span>AutoArch AI <b>·</b> Automotive Engineering Intelligence</span><span><ShieldCheck size={13}/> Prototype · Human review required</span></footer>
      </div>
    </main>
    {busy&&<div className="busy-indicator"><span className="spinner"/> Processing document…</div>}{toast&&<div className="toast"><Check size={16}/>{toast}</div>}
  </div>
}

function Nav({active,setTab,icon:Icon,id,label,badge}){return <button className={`nav-item ${active===id?'selected':''}`} onClick={()=>setTab(id)}><Icon size={17}/>{label}{badge&&<span className="beta">{badge}</span>}{active===id&&<span className="nav-dot"/>}</button>}
function Metric({icon,label,value,note,trend}){return <div className="metric-card"><div className="metric-top"><div className="metric-icon">{icon}</div><span className="metric-label">{trend}</span></div><div className="metric-value">{value}</div><div className="metric-title">{label}</div><div className="metric-note">{note}</div></div>}
function Signal({number,tone,title,text}){return <div className="signal-item"><div className={`signal-number ${tone}`}>{number}</div><div><strong>{title}</strong><p>{text}</p></div></div>}
function Principle({title,text}){return <div className="principle"><Check size={16}/><div><strong>{title}</strong><p>{text}</p></div></div>}
function Inventory({rows}){if(!rows.length)return <div className="empty-table">No matching entities were extracted from this document.</div>;return <div className="table-wrap"><table><thead><tr><th>ENTITY</th><th>CLASSIFICATION</th><th>SOURCE PAGES</th><th>REVIEW STATUS</th></tr></thead><tbody>{rows.map(c=><tr key={c.id||c.name}><td><div className="component-cell"><div className="component-mini"><Layers3 size={15}/></div><div><strong>{c.name}</strong><small>{c.evidence?.slice(0,85)}{c.evidence?.length>85?'…':''}</small></div></div></td><td><span className="type-pill">{c.type||'Interface / Signal'}</span></td><td><span className="page-pill">{(c.pages||[]).map(p=>`p.${p}`).join(', ')}</span></td><td><span className="review-status"><span/> Needs review</span></td></tr>)}</tbody></table></div>}
function Graph({nodes,edges}){if(!nodes.length)return <div className="graph-empty">No components detected yet. Import a document with architecture text.</div>;const positions=Object.fromEntries(nodes.map(n=>[n.name,n]));return <div className="graph-canvas"><svg viewBox="0 0 100 75" preserveAspectRatio="none" aria-label="Candidate dependency graph">{edges.map((e,i)=>positions[e.source]&&positions[e.target]&&<line key={i} x1={positions[e.source].x+8} y1={positions[e.source].y+4} x2={positions[e.target].x+8} y2={positions[e.target].y+4} stroke="#597a9d" strokeWidth=".35" strokeDasharray="1.2 1.1"/>)}</svg>{nodes.map((n,i)=><div className={`graph-node node-${i%5}`} key={n.id} style={{left:`${n.x}%`,top:`${n.y}%`}} title={n.evidence}><span className="node-dot"/><strong>{n.name}</strong><small>{n.type}</small></div>)}</div>}
function DiffList({title,rows,type}){return <div className="diff-list"><h3><span className={`diff-dot ${type}`}/>{title}<span>{rows.length}</span></h3>{rows.length?rows.map((r,i)=><p key={i}>{r}</p>):<div className="no-diff">No changes detected.</div>}</div>}
